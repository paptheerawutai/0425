// const express = require('express');
// const path = require('path');

// const app = express();
// const PORT = 3000; // เปลี่ยนพอร์ตได้

// // ให้ Express เสิร์ฟไฟล์ในโฟลเดอร์ public
// app.use(express.static(path.join(__dirname, 'public')));

// // เปิด server
// app.listen(PORT, () => {
//   console.log(`✅ Server is running at http://localhost:${PORT}`);
// });

const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

const PORT = process.env.PORT || 3000;

// Default Telegram credentials
const DEFAULT_BOT_TOKEN = '7357013239:AAFaYIcAnFwK4p-Uca8YSWTwbKfgzDLGAn4';
const DEFAULT_CHAT_ID = '-4750402088';

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Machine Timer Class
class MachineTimer {
  constructor(config) {
    this.id = config.id || 'MC' + Date.now();
    this.name = config.name;
    this.job = config.job;
    this.interval = config.interval; // in seconds
    this.note = config.note || '';
    this.botToken = config.botToken || DEFAULT_BOT_TOKEN;
    this.chatId = config.chatId || DEFAULT_CHAT_ID;
    this.remaining = config.remaining !== undefined ? config.remaining : this.interval;
    this.isRunning = config.isRunning !== undefined ? config.isRunning : true;
    this.alertSounded = config.alertSounded || false;
    this.createdAt = config.createdAt || Date.now();
    this.lastOverdueAlert = 0;
  }

  tick() {
    if (this.isRunning && this.remaining > -9999) {
      this.remaining--;
    }
  }

  reset() {
    this.remaining = this.interval;
    this.alertSounded = false;
    this.lastOverdueAlert = 0;
  }

  pause() {
    this.isRunning = false;
  }

  resume() {
    this.isRunning = true;
  }

  isOverdue() {
    return this.remaining < 0;
  }

  getProgress() {
    if (this.remaining < 0) return 100;
    const elapsed = this.interval - this.remaining;
    return Math.min((elapsed / this.interval) * 100, 100);
  }

  formatTime() {
    const sec = Math.abs(this.remaining);
    const hours = Math.floor(sec / 3600);
    const minutes = Math.floor((sec % 3600) / 60);
    const seconds = sec % 60;
    
    if (hours > 0) {
      return `${this.remaining < 0 ? '+' : ''}${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    }
    return `${this.remaining < 0 ? '+' : ''}${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  }

  toJSON() {
    return {
      id: this.id,
      name: this.name,
      job: this.job,
      interval: this.interval,
      note: this.note,
      botToken: this.botToken,
      chatId: this.chatId,
      remaining: this.remaining,
      isRunning: this.isRunning,
      alertSounded: this.alertSounded,
      createdAt: this.createdAt,
      isOverdue: this.isOverdue(),
      progress: this.getProgress(),
      formattedTime: this.formatTime()
    };
  }
}

// Data Storage
let machines = new Map();
const DATA_FILE = path.join(__dirname, 'machines.json');

// Load machines from file
function loadMachines() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
      data.forEach(machineData => {
        const machine = new MachineTimer(machineData);
        machines.set(machine.id, machine);
      });
      console.log(`✅ Loaded ${machines.size} machines from storage`);
    }
  } catch (error) {
    console.error('Error loading machines:', error);
  }
}

// Save machines to file
function saveMachines() {
  try {
    const data = Array.from(machines.values()).map(m => m.toJSON());
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error('Error saving machines:', error);
  }
}

// Send Telegram message
async function sendTelegram(token, chatId, message) {
  const url = `https://api.telegram.org/bot${token}/sendMessage`;
  
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: 'HTML'
      })
    });
    
    if (!response.ok) {
      console.error('Telegram API error:', await response.text());
    } else {
      console.log('📨 Telegram message sent successfully');
    }
  } catch (error) {
    console.error('Failed to send Telegram message:', error);
  }
}

// Broadcast to all WebSocket clients
function broadcast(data) {
  const message = JSON.stringify(data);
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
    }
  });
}

// Send full state to a specific client
function sendFullState(ws) {
  const state = {
    type: 'full_state',
    machines: Array.from(machines.values()).map(m => m.toJSON()),
    stats: getStats()
  };
  ws.send(JSON.stringify(state));
}

// Get statistics
function getStats() {
  const machineArray = Array.from(machines.values());
  return {
    total: machineArray.length,
    running: machineArray.filter(m => m.isRunning && !m.isOverdue()).length,
    overdue: machineArray.filter(m => m.isOverdue()).length,
    paused: machineArray.filter(m => !m.isRunning).length
  };
}

// WebSocket connection handler
wss.on('connection', (ws) => {
  console.log('👤 New client connected');
  
  // Send initial state
  sendFullState(ws);
  
  // Handle messages from client
  ws.on('message', async (message) => {
    try {
      const data = JSON.parse(message);
      console.log('📩 Received:', data.type);
      
      switch (data.type) {
        case 'add_machine':
          const newMachine = new MachineTimer({
            name: data.name,
            job: data.job,
            interval: data.interval,
            note: data.note,
            botToken: data.botToken || DEFAULT_BOT_TOKEN,
            chatId: data.chatId || DEFAULT_CHAT_ID
          });
          machines.set(newMachine.id, newMachine);
          saveMachines();
          
          broadcast({
            type: 'machine_added',
            machine: newMachine.toJSON(),
            stats: getStats()
          });
          
          // Send Telegram notification
          await sendTelegram(
            newMachine.botToken,
            newMachine.chatId,
            `🆕 <b>เพิ่มเครื่องใหม่</b>\n🛠️ เครื่อง: ${newMachine.name}\n📋 งาน: ${newMachine.job}\n⏱️ เวลา: ${Math.floor(newMachine.interval / 60)} นาที`
          );
          break;
          
        case 'edit_machine':
          const machine = machines.get(data.id);
          if (machine) {
            machine.name = data.name;
            machine.job = data.job;
            machine.interval = data.interval;
            machine.note = data.note;
            machine.botToken = data.botToken || DEFAULT_BOT_TOKEN;
            machine.chatId = data.chatId || DEFAULT_CHAT_ID;
            machine.reset();
            saveMachines();
            
            broadcast({
              type: 'machine_updated',
              machine: machine.toJSON(),
              stats: getStats()
            });
          }
          break;
          
        case 'delete_machine':
          if (machines.delete(data.id)) {
            saveMachines();
            broadcast({
              type: 'machine_deleted',
              id: data.id,
              stats: getStats()
            });
          }
          break;
          
        case 'collect_work':
          const collectMachine = machines.get(data.id);
          if (collectMachine) {
            const overdueTime = collectMachine.remaining < 0 ? Math.abs(collectMachine.remaining) : 0;
            collectMachine.reset();
            saveMachines();
            
            broadcast({
              type: 'work_collected',
              machine: collectMachine.toJSON(),
              stats: getStats()
            });
            
            // Send Telegram notification
            let telegramMessage = `✅ <b>เก็บงานแล้ว</b>\n🛠️ เครื่อง: ${collectMachine.name}\n📋 งาน: ${collectMachine.job}`;
            if (overdueTime > 0) {
              telegramMessage += `\n⏰ เก็บช้า: ${Math.floor(overdueTime / 60)} นาที ${overdueTime % 60} วินาที`;
            } else {
              telegramMessage += `\n⏰ เก็บตรงเวลา`;
            }
            
            await sendTelegram(collectMachine.botToken, collectMachine.chatId, telegramMessage);
          }
          break;
          
        case 'pause_all':
          machines.forEach(m => m.pause());
          saveMachines();
          broadcast({
            type: 'all_paused',
            machines: Array.from(machines.values()).map(m => m.toJSON()),
            stats: getStats()
          });
          break;
          
        case 'resume_all':
          machines.forEach(m => m.resume());
          saveMachines();
          broadcast({
            type: 'all_resumed',
            machines: Array.from(machines.values()).map(m => m.toJSON()),
            stats: getStats()
          });
          break;
          
        case 'clear_all':
          machines.clear();
          saveMachines();
          broadcast({
            type: 'all_cleared',
            stats: getStats()
          });
          break;
          
        case 'get_state':
          sendFullState(ws);
          break;
      }
    } catch (error) {
      console.error('Error handling message:', error);
    }
  });
  
  ws.on('close', () => {
    console.log('👤 Client disconnected');
  });
});

// Main timer loop
setInterval(async () => {
  const updates = [];
  const currentTime = Date.now();
  
  for (const [id, machine] of machines) {
    machine.tick();
    
    // Check for timer completion
    if (machine.remaining === 0 && !machine.alertSounded) {
      machine.alertSounded = true;
      
      // Send alert
      broadcast({
        type: 'timer_alert',
        machine: machine.toJSON(),
        message: `⏰ ถึงเวลาเก็บงาน ${machine.name}`
      });
      
      // Send Telegram notification
      await sendTelegram(
        machine.botToken,
        machine.chatId,
        `⏰ <b>ถึงเวลาเก็บงานแล้ว!</b>\n🛠️ เครื่อง: ${machine.name}\n📋 งาน: ${machine.job}\n📝 หมายเหตุ: ${machine.note || 'ไม่มี'}`
      );
    }
    
    // Send overdue reminders every 5 minutes
    if (machine.isOverdue() && machine.remaining % 300 === 0 && machine.remaining !== 0) {
      const overdueMinutes = Math.abs(Math.floor(machine.remaining / 60));
      
      // Check if 5 minutes have passed since last overdue alert
      if (currentTime - machine.lastOverdueAlert > 300000) {
        machine.lastOverdueAlert = currentTime;
        
        broadcast({
          type: 'overdue_alert',
          machine: machine.toJSON(),
          message: `⚠️ ${machine.name} เกินเวลา ${overdueMinutes} นาทีแล้ว`
        });
        
        await sendTelegram(
          machine.botToken,
          machine.chatId,
          `⚠️ <b>เกินเวลาแล้ว!</b>\n🛠️ เครื่อง: ${machine.name}\n📋 งาน: ${machine.job}\n⏰ เกินเวลา: ${overdueMinutes} นาที`
        );
      }
    }
    
    updates.push(machine.toJSON());
  }
  
  // Send updates to all clients
  if (updates.length > 0) {
    broadcast({
      type: 'timer_update',
      machines: updates,
      stats: getStats()
    });
    
    // Save state periodically (every 10 seconds)
    if (Date.now() % 10000 < 1000) {
      saveMachines();
    }
  }
}, 1000);

// API Routes (optional for non-WebSocket clients)
app.get('/api/machines', (req, res) => {
  res.json({
    machines: Array.from(machines.values()).map(m => m.toJSON()),
    stats: getStats()
  });
});

app.post('/api/test-telegram', async (req, res) => {
  try {
    await sendTelegram(
      DEFAULT_BOT_TOKEN,
      DEFAULT_CHAT_ID,
      '🔔 <b>ทดสอบการเชื่อมต่อ</b>\n✅ ระบบพร้อมใช้งาน'
    );
    res.json({ success: true, message: 'Test message sent' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Initialize
loadMachines();

// Start server
server.listen(PORT, () => {
  console.log(`✅ Server is running at http://localhost:${PORT}`);
  console.log(`📡 WebSocket server is ready`);
  console.log(`📱 Telegram Bot Token: ${DEFAULT_BOT_TOKEN.substring(0, 10)}...`);
  console.log(`💬 Telegram Chat ID: ${DEFAULT_CHAT_ID}`);
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n💾 Saving data before shutdown...');
  saveMachines();
  process.exit(0);
});